import os

os.system("pyinstaller main.py --onefile --clean --noconfirm --noconsole --windowed --name=main.exe")