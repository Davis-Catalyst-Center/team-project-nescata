import pygame
import engine.core

def menu(nes_core: engine.core.Core)
